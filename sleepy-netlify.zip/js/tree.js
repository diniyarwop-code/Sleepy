/* Sleepy — SVG: дерево (4 ветки × 5 стадий) и ночной питомец-сова */
(function (root) {
  'use strict';

  const circle = (cx, cy, r, fill, op) => '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="' + fill + '"' + (op != null ? ' opacity="' + op + '"' : '') + '/>';
  const ell = (cx, cy, rx, ry, fill, extra) => '<ellipse cx="' + cx + '" cy="' + cy + '" rx="' + rx + '" ry="' + ry + '" fill="' + fill + '"' + (extra || '') + '/>';

  const FLY = [[52, 150], [188, 140], [70, 96], [172, 92], [40, 118], [200, 112], [96, 64], [146, 60], [120, 40], [62, 176], [182, 172], [120, 86]];

  const PAL = {
    oak:    { young: '#6fdc9a', young2: '#4fb97c', crown: '#5fcf8a', crown2: '#3fa56a', crown3: '#86e6ac', trunk: '#8a5a3c', trunk2: '#6d4530', flower: '#ffd86b', ground: '#2c4a3a', ground2: '#1b2f2b' },
    sakura: { young: '#7fdc9f', young2: '#58b97f', crown: '#f6a9c6', crown2: '#e987ad', crown3: '#ffd0e0', trunk: '#7a5240', trunk2: '#5d3d30', flower: '#fff1f6', ground: '#2c4a3a', ground2: '#1b2f2b' },
    cactus: { body: '#5fcf9a', body2: '#3fa878', body3: '#8ae6b8', flower: '#ff8fb5', ground: '#6b5a45', ground2: '#4a3d30' },
    bonsai: { young: '#74dca0', young2: '#4fb97c', crown: '#4fbf86', crown2: '#379a68', crown3: '#7ee0a8', trunk: '#8a5a3c', trunk2: '#6d4530', flower: '#ffb7d0', ground: '#2c3a4a', ground2: '#1b2430', pot: '#c4704a', pot2: '#9c5236' }
  };

  function leafy(P, stage, sakura) {
    let g = '';
    if (stage === 0) {
      g += '<path d="M120 208 Q118 192 120 176" stroke="' + P.young2 + '" stroke-width="5" fill="none" stroke-linecap="round"/>';
      g += '<path d="M120 182 Q100 176 96 160 Q114 160 120 182Z" fill="' + P.young + '"/>';
      g += '<path d="M120 178 Q142 170 146 154 Q126 154 120 178Z" fill="' + P.young2 + '"/>';
    } else if (stage === 1) {
      g += '<path d="M120 208 Q116 180 120 146" stroke="' + P.young2 + '" stroke-width="6" fill="none" stroke-linecap="round"/>';
      [[104, 188, 86, 178], [136, 180, 154, 168], [106, 160, 88, 148], [134, 152, 152, 140]].forEach((l, i) => {
        g += '<path d="M120 ' + (l[1] - 4) + ' Q' + l[0] + ' ' + (l[1] - 14) + ' ' + l[2] + ' ' + l[3] + ' Q' + (l[0] + (i % 2 ? 4 : -4)) + ' ' + (l[1] + 2) + ' 120 ' + (l[1] - 4) + 'Z" fill="' + (i % 2 ? P.young2 : P.young) + '"/>';
      });
      g += '<path d="M120 150 Q108 134 120 120 Q132 134 120 150Z" fill="' + P.young + '"/>';
    } else if (stage === 2) {
      g += circle(92, 184, 26, P.young2) + circle(148, 184, 26, P.young2) + circle(120, 168, 32, P.young) + circle(120, 190, 24, P.young);
      g += circle(108, 160, 10, P.crown3, 0.5) + circle(138, 176, 8, P.crown3, 0.4);
      if (sakura) g += circle(100, 172, 4, P.flower) + circle(138, 160, 4, P.flower) + circle(120, 184, 4, P.flower);
    } else {
      g += '<path d="M112 210 L114 140 Q120 134 126 140 L128 210Z" fill="' + P.trunk + '"/>';
      g += '<path d="M120 170 Q100 158 92 140" stroke="' + P.trunk + '" stroke-width="7" fill="none" stroke-linecap="round"/>';
      g += '<path d="M120 160 Q142 148 150 130" stroke="' + P.trunk + '" stroke-width="7" fill="none" stroke-linecap="round"/>';
      g += '<path d="M118 150 L118 208" stroke="' + P.trunk2 + '" stroke-width="3" opacity=".5"/>';
      g += circle(84, 118, 32, P.crown2) + circle(156, 118, 32, P.crown2) + circle(120, 94, 44, P.crown) + circle(98, 128, 30, P.crown) + circle(144, 130, 30, P.crown) + circle(120, 122, 34, P.crown);
      g += circle(104, 80, 14, P.crown3, 0.55) + circle(142, 104, 10, P.crown3, 0.45) + circle(80, 112, 9, P.crown3, 0.4);
      if (stage >= 4) {
        const f = [[96, 70], [132, 62], [150, 96], [70, 110], [168, 122], [112, 108], [90, 138], [140, 140], [122, 82], [104, 124], [160, 100], [78, 130]];
        f.forEach((p, i) => { g += circle(p[0], p[1], i % 3 === 0 ? 6 : 4.5, P.flower) + circle(p[0], p[1], 1.8, sakura ? '#f3a0bd' : '#ff9f6b'); });
      }
    }
    return g;
  }

  function cactus(P, stage) {
    let g = '';
    const body = (x, y, w, h, r) => '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="' + r + '" fill="' + P.body + '"/>';
    const ribs = (x, y, w, h) => '<rect x="' + (x + w / 2 - 1.5) + '" y="' + (y + 6) + '" width="3" height="' + (h - 10) + '" rx="1.5" fill="' + P.body2 + '" opacity=".55"/>';
    const spines = (pts) => pts.map((p) => '<path d="M' + p[0] + ' ' + p[1] + ' l3 -3 M' + p[0] + ' ' + p[1] + ' l-3 -3" stroke="#e9f7e0" stroke-width="1.3" stroke-linecap="round"/>').join('');
    if (stage === 0) {
      g += ell(120, 200, 11, 13, P.body) + ell(120, 200, 3, 10, P.body2, ' opacity=".5"') + spines([[120, 190], [114, 198], [126, 198]]);
    } else if (stage === 1) {
      g += body(104, 154, 32, 56, 16) + ribs(104, 154, 32, 56) + spines([[112, 170], [128, 176], [118, 190], [128, 198]]);
    } else if (stage === 2) {
      g += body(100, 116, 40, 94, 20) + ribs(100, 116, 40, 94) + ell(112, 140, 4, 18, P.body3, ' opacity=".35"') + spines([[110, 136], [130, 150], [112, 168], [130, 184], [118, 196]]);
    } else {
      g += body(100, 104, 40, 106, 20) + ribs(100, 104, 40, 106);
      g += '<path d="M100 160 H82 Q70 160 70 148 V132" stroke="' + P.body + '" stroke-width="18" fill="none" stroke-linecap="round" stroke-linejoin="round"/>';
      g += '<path d="M140 148 H158 Q170 148 170 136 V116" stroke="' + P.body + '" stroke-width="18" fill="none" stroke-linecap="round" stroke-linejoin="round"/>';
      g += ell(112, 130, 4, 20, P.body3, ' opacity=".35"') + spines([[110, 124], [130, 140], [112, 160], [130, 178], [70, 128], [170, 118], [118, 196]]);
      if (stage >= 4) {
        const fl = (x, y, s) => circle(x, y, 8 * s, P.flower) + circle(x - 7 * s, y + 3 * s, 5.5 * s, P.flower) + circle(x + 7 * s, y + 3 * s, 5.5 * s, P.flower) + circle(x, y, 3 * s, '#ffe08a');
        g += fl(120, 100, 1) + fl(70, 124, 0.7) + fl(170, 112, 0.7);
      }
    }
    return g;
  }

  function bonsai(P, stage) {
    let g = '';
    const pot = '<path d="M86 196 H154 L146 222 Q120 228 94 222Z" fill="' + P.pot + '"/><rect x="82" y="190" width="76" height="10" rx="5" fill="' + P.pot2 + '"/>';
    const soil = ell(120, 192, 34, 5, '#3b2a22');
    if (stage === 0) {
      g += '<path d="M120 192 Q118 180 121 170" stroke="' + P.young2 + '" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M121 174 Q106 170 102 158 Q118 158 121 174Z" fill="' + P.young + '"/><path d="M121 172 Q138 166 142 154 Q124 154 121 172Z" fill="' + P.young2 + '"/>';
    } else if (stage === 1) {
      g += '<path d="M120 192 Q108 170 124 148" stroke="' + P.trunk + '" stroke-width="6" fill="none" stroke-linecap="round"/>';
      g += ell(126, 144, 18, 11, P.crown) + ell(106, 166, 14, 8, P.crown2) + ell(138, 160, 13, 8, P.crown);
    } else if (stage === 2) {
      g += '<path d="M118 192 Q100 168 122 146 Q132 134 124 118" stroke="' + P.trunk + '" stroke-width="8" fill="none" stroke-linecap="round"/>';
      g += ell(122, 112, 28, 15, P.crown) + ell(94, 150, 22, 11, P.crown2) + ell(144, 140, 20, 10, P.crown) + ell(118, 128, 14, 7, P.crown3, ' opacity=".5"');
    } else {
      g += '<path d="M118 192 Q96 166 120 142 Q142 122 120 98" stroke="' + P.trunk + '" stroke-width="10" fill="none" stroke-linecap="round"/>';
      g += '<path d="M112 160 Q86 154 78 134" stroke="' + P.trunk + '" stroke-width="6" fill="none" stroke-linecap="round"/>';
      g += '<path d="M126 134 Q152 128 162 110" stroke="' + P.trunk + '" stroke-width="6" fill="none" stroke-linecap="round"/>';
      g += ell(120, 86, 34, 17, P.crown) + ell(76, 124, 24, 12, P.crown2) + ell(164, 102, 24, 12, P.crown) + ell(96, 158, 22, 10, P.crown2) + ell(116, 78, 16, 7, P.crown3, ' opacity=".5"') + ell(160, 98, 11, 5, P.crown3, ' opacity=".5"');
      if (stage >= 4) {
        [[100, 80], [136, 84], [70, 120], [84, 128], [160, 98], [172, 106], [96, 154], [114, 82]].forEach((p, i) => { g += circle(p[0], p[1], i % 2 ? 4.5 : 6, P.flower) + circle(p[0], p[1], 1.8, '#f08aa8'); });
      }
    }
    return { pot: pot + soil, plant: g };
  }

  function treeSVG(branch, stage, extra) {
    branch = branch || 'oak';
    stage = Math.max(0, Math.min(4, stage | 0));
    extra = Math.max(0, extra | 0);
    const P = PAL[branch] || PAL.oak;
    let body = '', under = '';
    under += ell(120, 214, 84, 14, P.ground2, ' opacity=".8"') + ell(120, 209, 66, 10, P.ground);
    if (branch === 'cactus') body = '<g class="sway">' + cactus(P, stage) + '</g>';
    else if (branch === 'bonsai') { const b = bonsai(P, stage); under = ell(120, 226, 70, 8, P.ground2, ' opacity=".7"'); body = b.pot + '<g class="sway">' + b.plant + '</g>'; }
    else body = '<g class="sway">' + leafy(P, stage, branch === 'sakura') + '</g>';

    let flies = '';
    for (let i = 0; i < Math.min(extra, FLY.length); i++) {
      flies += '<circle class="fly" style="animation-delay:' + (i * 0.37).toFixed(2) + 's" cx="' + FLY[i][0] + '" cy="' + FLY[i][1] + '" r="3" fill="#ffe27a"/>';
    }
    return '<svg class="tree-svg" viewBox="0 0 240 240" role="img" aria-label="Дерево" xmlns="http://www.w3.org/2000/svg"><defs><radialGradient id="tglow" cx="50%" cy="60%" r="55%"><stop offset="0" stop-color="#6fdc9a" stop-opacity=".16"/><stop offset="1" stop-color="#6fdc9a" stop-opacity="0"/></radialGradient></defs>'
      + '<rect width="240" height="240" fill="url(#tglow)"/>' + under + body + flies + '</svg>';
  }

  /* Сова: уровень 0–3 */
  function petSVG(level, mood) {
    level = Math.max(0, Math.min(3, level | 0));
    const s = level === 0 ? 0.84 : 1;
    let g = '';
    if (level >= 3) {
      g += '<g class="twinkle"><path d="M30 34 l3 7 7 3 -7 3 -3 7 -3 -7 -7 -3 7 -3z" fill="#ffd86b"/><path d="M132 24 l2 5 5 2 -5 2 -2 5 -2 -5 -5 -2 5 -2z" fill="#ffd86b"/><path d="M142 70 l1.6 4 4 1.6 -4 1.6 -1.6 4 -1.6 -4 -4 -1.6 4 -1.6z" fill="#fff3c4"/></g>';
    }
    g += '<g transform="translate(80 ' + (level === 0 ? 14 : 4) + ') scale(' + s + ') translate(-80 0)">';
    g += '<path d="M40 52 L48 22 L70 42Z" fill="#6f61e8"/><path d="M120 52 L112 22 L90 42Z" fill="#6f61e8"/>';
    g += ell(80, 96, 48, 52, '#8576ff');
    g += ell(80, 112, 30, 34, '#c9c2ff');
    [[68, 108], [80, 114], [92, 108], [74, 124], [86, 124]].forEach((p) => { g += '<path d="M' + (p[0] - 4) + ' ' + p[1] + ' q4 4 8 0" stroke="#9d92ff" stroke-width="2" fill="none" stroke-linecap="round"/>'; });
    g += ell(36, 104, 11, 28, '#6f61e8', ' transform="rotate(8 36 104)"') + ell(124, 104, 11, 28, '#6f61e8', ' transform="rotate(-8 124 104)"');
    g += circle(62, 78, 16, '#fff') + circle(98, 78, 16, '#fff');
    g += '<g class="blink">' + circle(64, 80, 8, '#1d1b3a') + circle(96, 80, 8, '#1d1b3a') + circle(67, 77, 2.6, '#fff') + circle(99, 77, 2.6, '#fff') + '</g>';
    g += '<path d="M74 92 L80 102 L86 92Z" fill="#ffc94d"/>';
    g += '<path d="M66 148 l-4 8 M74 150 l-2 8 M94 150 l2 8 M102 148 l4 8" stroke="#ffc94d" stroke-width="3" stroke-linecap="round"/>';
    if (mood === 'happy') g += '<path d="M54 94 q4 4 8 0 M98 94 q4 4 8 0" stroke="#ff9fb8" stroke-width="2.4" fill="none" stroke-linecap="round" opacity=".9"/>';
    if (level >= 1) { /* колпак для сна */
      g += '<path d="M46 50 Q80 -4 118 30 Q106 42 92 40 Q70 30 46 50Z" fill="#ffd86b"/><path d="M44 52 Q80 38 118 34 L114 44 Q80 46 48 60Z" fill="#fff3c4"/>' + circle(120, 30, 6, '#fff3c4');
    }
    if (level >= 2) { /* месяц на груди */
      g += '<path d="M80 118 a12 12 0 1 0 8 20 a9 9 0 1 1 -8 -20z" fill="#ffd86b" opacity=".95"/>';
    }
    g += '</g>';
    return '<svg class="pet-svg" viewBox="0 0 160 170" role="img" aria-label="Ночной питомец" xmlns="http://www.w3.org/2000/svg">' + g + '</svg>';
  }

  const api = { treeSVG, petSVG };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.SleepyArt = api;
})(typeof window !== 'undefined' ? window : globalThis);
