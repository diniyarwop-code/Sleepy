/* Sleepy — интерфейс */
(function () {
  'use strict';
  const L = window.SleepyLogic, A = window.SleepyArt;
  const KEY = 'sleepy:v1';

  /* ---------- Хранение ---------- */
  function load() {
    try { const raw = localStorage.getItem(KEY); if (raw) return L.normalizeState(JSON.parse(raw)); } catch (e) { /* пусто */ }
    return L.newState();
  }
  let storageWarned = false;
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(state)); }
    catch (e) { if (!storageWarned) { storageWarned = true; toast('Браузер не даёт сохранять данные. Используй «Экспорт» в профиле, чтобы не потерять прогресс.'); } }
  }
  let state = load();

  /* ---------- Утилиты ---------- */
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const today = () => L.dateStr(new Date());
  const num = (n) => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  const sg = (n) => (n > 0 ? '+' + L.fmtNum(n) : n < 0 ? '−' + L.fmtNum(Math.abs(n)) : '0');
  const MONTHS = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
  const MONTHS_S = ['янв', 'фев', 'мар', 'апр', 'мая', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
  const WD = ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'];
  const WD_S = ['вс', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб'];
  const dLong = (s) => { const d = L.parseDate(s); return d.getDate() + ' ' + MONTHS[d.getMonth()]; };
  const dShort = (s) => { const d = L.parseDate(s); return d.getDate() + ' ' + MONTHS_S[d.getMonth()]; };
  const wd = (s) => WD[L.parseDate(s).getDay()];

  const IC = {
    gem: '<svg class="ic" viewBox="0 0 24 24"><path d="M6 3h12l4 6-10 12L2 9z" fill="#ffd86b"/><path d="M2 9h20M9 3l-2 6 5 12 5-12-2-6" fill="none" stroke="#b8861a" stroke-width="1.2" stroke-linejoin="round"/></svg>',
    drop: '<svg class="ic" viewBox="0 0 24 24"><path d="M12 2.5C9 7 5.5 10.2 5.5 14.5a6.5 6.5 0 0 0 13 0C18.5 10.2 15 7 12 2.5z" fill="#6ac8ff"/><path d="M9 15a3.2 3.2 0 0 0 3 3" fill="none" stroke="#dff4ff" stroke-width="1.6" stroke-linecap="round"/></svg>',
    flame: '<svg class="ic" viewBox="0 0 24 24"><path d="M12 2c1 4 5 6 5 11a5 5 0 0 1-10 0c0-2 1-3.2 2-4.2.2 1.4.8 2.2 1.6 2.6C10 8 10.6 4.6 12 2z" fill="#ff9d5c"/><path d="M12 22a3 3 0 0 1-3-3c0-1.6 1.5-2.2 3-4 1.5 1.8 3 2.4 3 4a3 3 0 0 1-3 3z" fill="#ffd86b"/></svg>',
    check: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>'
  };
  const TABS = [
    { id: 'today', label: 'Сегодня', svg: '<path d="M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5z"/>' },
    { id: 'stats', label: 'Статистика', svg: '<path d="M5 20v-9M12 20V4M19 20v-6"/>' },
    { id: 'goals', label: 'Цели', svg: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r=".6"/>' },
    { id: 'shop', label: 'Магазин', svg: '<path d="M5 8h14l-1 12H6L5 8z"/><path d="M9 8a3 3 0 0 1 6 0"/>' },
    { id: 'profile', label: 'Профиль', svg: '<circle cx="12" cy="8" r="4"/><path d="M4 20c1-4 4-6 8-6s7 2 8 6"/>' },
    { id: 'rules', label: 'Правила', svg: '<path d="M5 4h10a4 4 0 0 1 4 4v12H9a4 4 0 0 1-4-4V4z"/><path d="M9 8h6M9 12h6"/>' }
  ];

  /* ---------- Состояние интерфейса ---------- */
  const ui = { tab: 'today', date: today(), todayRef: today(), bed: '', wake: '', msg: '', goalTitle: '', goalCost: '', justSaved: false, justWatered: false };
  function loadForm(date) {
    const e = state.entries[date];
    ui.bed = e ? e.bed : ''; ui.wake = e ? e.wake : ''; ui.msg = '';
  }
  loadForm(ui.date);

  /* ---------- Тосты, модалки, эффекты ---------- */
  function toast(text) {
    const root = $('#toasts');
    while (root.children.length >= 2) root.removeChild(root.firstChild);
    const t = document.createElement('div'); t.className = 'toast'; t.textContent = text; root.appendChild(t);
    setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 320); }, 3400);
  }
  function modal(o) {
    const root = $('#modal-root');
    root.innerHTML = '<div class="overlay" data-close="1"><div class="modal" role="dialog" aria-modal="true">'
      + (o.emoji ? '<span class="emoji">' + o.emoji + '</span>' : '') + '<h2>' + o.title + '</h2>' + (o.body || '')
      + '<div class="actions">' + (o.actions || []).map((a, i) => '<button class="btn ' + (a.cls || '') + '" data-modal-act="' + i + '">' + a.label + '</button>').join('') + '</div></div></div>';
    const ov = $('.overlay', root);
    ov.addEventListener('click', (ev) => {
      if (ev.target === ov && o.dismissible !== false) closeModal();
      const b = ev.target.closest('[data-modal-act]');
      if (b) { const a = o.actions[+b.dataset.modalAct]; if (a.keep !== true) closeModal(); if (a.onClick) a.onClick(); }
      const opt = ev.target.closest('[data-branch]');
      if (opt && o.onBranch) o.onBranch(opt.dataset.branch);
    });
    const first = $('button:not(:disabled)', ov); if (first) first.focus();
  }
  function closeModal() { $('#modal-root').innerHTML = ''; }
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

  function floaty(el, text, color) {
    if (!el) return;
    const r = el.getBoundingClientRect(); const s = document.createElement('div');
    s.className = 'floaty'; s.textContent = text; s.style.color = color;
    s.style.left = (r.left + r.width / 2 - 24) + 'px'; s.style.top = (r.bottom - 6) + 'px';
    document.body.appendChild(s); setTimeout(() => s.remove(), 1600);
  }

  function handleEvents(events) {
    (events || []).forEach((e) => {
      if (e.text && !e.branchUnlock) toast(e.text + (e.c ? ' · +' + e.c + ' 💎' : ''));
      if (e.branchUnlock && !state.branchPrompted) { state.branchPrompted = true; save(); setTimeout(() => branchModal('first'), 700); }
    });
  }

  /* ---------- Шапка ---------- */
  const prev = { c: null, d: null };
  function renderTop() {
    const st = L.computeStreak(state, today());
    $('#stats-bar').innerHTML =
      '<div class="pill cr" id="p-c">' + IC.gem + '<b>' + num(state.crystals) + '</b><small>кристаллы</small></div>'
      + '<div class="pill dr" id="p-d">' + IC.drop + '<b>' + L.fmtNum(state.drops) + '</b><small>капли</small></div>'
      + '<div class="pill st" id="p-s">' + IC.flame + '<b>' + st + '</b><small>' + L.plural(st, ['день', 'дня', 'дней']) + ' подряд</small></div>';
    const bump = (id, a, b, color, unit) => {
      if (a == null || a === b) return;
      const el = $(id); if (!el) return;
      el.classList.add('pop'); floaty(el, sg(L.round2(b - a)) + ' ' + unit, color);
    };
    bump('#p-c', prev.c, state.crystals, '#ffd86b', '💎');
    bump('#p-d', prev.d, state.drops, '#6ac8ff', '💧');
    prev.c = state.crystals; prev.d = state.drops;
  }

  /* ---------- Навигация ---------- */
  function renderTabs() {
    $('#tabs').innerHTML = TABS.map((t) => '<button role="tab" data-tab="' + t.id + '" aria-selected="' + (ui.tab === t.id) + '"><svg viewBox="0 0 24 24" aria-hidden="true">' + t.svg + '</svg>' + t.label + '</button>').join('');
  }
  function showTab(id, noScroll) {
    ui.tab = id;
    $$('.screen').forEach((s) => s.classList.toggle('hide', s.dataset.screen !== id));
    renderTabs(); renderScreen(id);
    if (!noScroll) window.scrollTo(0, 0);
  }
  function renderScreen(id) { ({ today: renderToday, stats: renderStats, goals: renderGoals, shop: renderShop, profile: renderProfile, rules: renderRules })[id](); }
  function renderAll() { renderTop(); renderScreen(ui.tab); }

  /* ---------- СЕГОДНЯ ---------- */
  function petSay() {
    const n = state.petName, t = today(), e = state.entries[t], st = L.computeStreak(state, t);
    if (!Object.keys(state.entries).length) return 'Привет! Я ' + esc(n) + '. Запиши первую ночь — и мы начнём растить дерево 🌱';
    if (e) {
      if (e.crystals >= 100) return 'Отличная ночь! Мы с деревом тобой гордимся ✨';
      if (e.crystals > 0) return 'Ночь записана. Каждая такая — маленький шаг, и он засчитан 🌙';
      return 'Бывает! Завтра новый вечер, и я буду рядом 🤍';
    }
    const h = new Date().getHours();
    const hi = h < 5 ? 'Не спится?' : h < 12 ? 'Доброе утро!' : h < 18 ? 'Привет!' : 'Добрый вечер!';
    if (st >= 3) return hi + ' Уже ' + st + ' ' + L.plural(st, ['день', 'дня', 'дней']) + ' подряд — так держать. Как спалось?';
    return hi + ' Как спалось? Запиши ночь — я подожду.';
  }

  function boosterChips() {
    const b = state.boosters, out = [];
    if (b.freeze) out.push('❄️ Заморозка серии');
    if (b.double) out.push('💧 Двойные капли');
    if (b.shield) out.push('🛡️ Щит от штрафа');
    if (b.alarm) out.push('⏰ Ранний будильник');
    return out;
  }

  function resultHTML(e) {
    const st = L.computeStreak(state, today());
    const ok = L.qualifies(e);
    const lines = (e.lines || []).filter((l) => l.c !== 0 || l.d !== 0 || /Щит/.test(l.text)).map((l) =>
      '<li><span>' + esc(l.text) + '</span><span>'
      + (l.c ? '<b class="' + (l.c > 0 ? 'pos' : 'neg') + '">' + sg(l.c) + ' 💎</b> ' : '')
      + (l.d ? '<b class="posd">' + sg(l.d) + ' 💧</b>' : '') + '</span></li>').join('');
    let note;
    if (e.shielded) note = 'Щит принял штраф на себя — кристаллы целы 🛡️';
    else if (e.tier < 0) note = 'Поздно получилось — ничего страшного. Баланс не уходит ниже нуля, а завтра новый вечер 🌙';
    else if (!ok) note = 'Серия начнётся заново с ближайшей ночи — каждый вечер новый шанс.';
    else if (e.tier >= 150) note = 'Отличный отбой! Так держать ✨';
    else note = 'Ночь засчитана. Дерево тебя ждёт 🌱';
    return '<div class="result" id="result">'
      + '<div class="big"><div><b>' + L.fmtHours(e.hours).replace(' мин', 'м').replace(' ч ', 'ч ') + '</b><small>сон</small></div>'
      + '<div><b class="' + (e.crystals < 0 ? 'neg' : 'pos') + '">' + sg(e.crystals) + '</b><small>кристаллы</small></div>'
      + '<div><b class="posd">' + sg(e.drops) + '</b><small>капли</small></div>'
      + '<div><b>' + st + '</b><small>серия</small></div></div>'
      + '<ul class="lines">' + lines + '</ul><div class="note">' + note + '</div></div>';
  }

  function renderToday() {
    const el = $('#screen-today'), t = today();
    const date = ui.date, e = state.entries[date];
    const w = L.WEATHER[L.weatherFor(date)];
    const stage = L.stageOf(state), extra = L.extraOf(state);
    const lvl = L.petLevel(state);
    const chips = boosterChips();
    const quests = L.questsFor(state, t), qs = state.quests[t];
    const unlocked = L.branchUnlocked(state);
    const br = state.branch ? L.BRANCHES[state.branch] : null;
    const label = date === t ? 'Сегодня' : date === L.addDays(t, -1) ? 'Вчера' : '';

    const treeHint = stage < 4
      ? 'Следующая стадия: <b>' + L.STAGES[stage + 1] + '</b>'
      : 'Дерево цветёт ✨ Новые капли превращаются в светлячков' + (extra ? ' (' + Math.min(extra, 12) + ')' : '');
    const need = Math.max(0, L.round2(L.WATER_COST - state.drops));
    const q = qs.chest;

    el.innerHTML =
      '<div class="hello"><div class="pet-mini">' + A.petSVG(lvl.level, e && e.crystals > 0 ? 'happy' : '') + '</div><div class="bubble grow">' + petSay() + '</div></div>'

      + '<div class="card"><div class="weather"><div class="wi">' + w.icon + '</div><div class="grow"><div class="small muted">Погода сна · ' + (label ? label + ', ' : '') + dLong(date) + '</div><b>' + w.name + '</b><p class="small muted">' + w.desc + '</p></div></div>'
      + (chips.length ? '<div class="boosters">' + chips.map((c) => '<span class="chip on">' + c + '</span>').join('') + '</div>' : '') + '</div>'

      + '<div class="card"><h2>' + (e ? 'Запись за ' + dLong(date) : 'Запиши ночь') + '</h2>'
      + '<div class="date-row"><input class="inp grow" type="date" id="f-date" value="' + date + '" max="' + t + '" aria-label="Дата">'
      + '<button class="chip" data-act="date-today">Сегодня</button><button class="chip" data-act="date-yest">Вчера</button></div>'
      + '<div class="times"><div><label class="f" for="f-bed">Лёг спать</label><input class="inp" type="time" id="f-bed" value="' + ui.bed + '"></div>'
      + '<div><label class="f" for="f-wake">Проснулся</label><input class="inp" type="time" id="f-wake" value="' + ui.wake + '"></div></div>'
      + '<button class="btn block" data-act="save-entry">' + (e ? 'Обновить запись' : 'Сохранить ночь') + '</button>'
      + (ui.msg ? '<div class="msg">' + esc(ui.msg) + '</div>' : '')
      + '<p class="small muted" style="margin-top:10px">Отбой после полуночи записывай как есть, например 00:10. Можно записать любой прошлый день.</p>'
      + (e ? resultHTML(e) : '') + '</div>'

      + '<div class="card tree-card" id="tree-card"><h2>Твоё дерево' + (br ? ' · ' + br.icon + ' ' + br.name : '') + '</h2>'
      + '<div class="tree-wrap">' + A.treeSVG(state.branch, stage, extra) + '</div>'
      + '<div class="stage-dots">' + [0, 1, 2, 3, 4].map((i) => '<i class="' + (i <= stage ? 'on' : '') + '"></i>').join('') + '</div>'
      + '<b>' + L.STAGES[stage] + '</b><p class="small muted" style="margin-top:2px">' + treeHint + '</p>'
      + (br ? '<p class="small" style="margin-top:6px;color:var(--leaf)">' + br.desc + '</p>' : '')
      + '<div style="margin-top:14px"><button class="btn drop block" data-act="water"' + (state.drops < L.WATER_COST ? ' disabled' : '') + '>💧 Полить · 5 капель</button>'
      + (state.drops < L.WATER_COST ? '<p class="small muted" style="margin-top:8px">Не хватает ' + L.fmtNum(need) + ' капель. Они копятся с каждой ночью и никогда не сгорают.</p>' : '')
      + '</div>'
      + (unlocked && !state.branch ? '<button class="btn leaf block" style="margin-top:10px" data-act="branch-first">🌳 Выбрать ветку развития</button>' : '')
      + (!unlocked ? '<p class="small muted" style="margin-top:10px">На 7-й день серии откроется выбор ветки: дуб, сакура, кактус или бонсай (сейчас серия ' + L.computeStreak(state, t) + ').</p>' : '')
      + '</div>'

      + '<div class="card"><div class="row between"><h2>Квесты дня</h2><span class="small muted">' + quests.filter((x) => x.done).length + ' из 3</span></div>'
      + quests.map((x) => '<div class="quest' + (x.done ? ' done' : '') + '"><span class="qcheck">' + (x.done ? IC.check : '') + '</span><span class="grow qt">' + x.text + '</span><span class="qr">+' + x.reward + ' 💎</span></div>').join('')
      + '<div class="row" style="margin-top:12px;gap:14px"><span class="chest ' + (q === 'ready' ? 'ready' : '') + '">' + (q === 'opened' ? '📭' : '🎁') + '</span><div class="grow">'
      + (q === 'ready' ? '<button class="btn block" data-act="open-qchest">Открыть сундук квестов</button>'
        : q === 'opened' ? '<p class="small muted">Сундук квестов уже открыт. Завтра будут новые квесты.</p>'
        : '<p class="small muted">Выполни все три квеста — откроется сундук: 100–500 кристаллов или 2–5 капель.</p>')
      + '</div></div></div>'

      + '<div class="card"><div class="row" style="gap:14px"><span class="chest" style="font-size:40px">🧰</span><div class="grow"><h3>Бесплатный сундук</h3>'
      + '<p class="small muted" id="chest-hint"></p></div></div><button class="btn leaf block" style="margin-top:12px" data-act="open-fchest" id="chest-btn">Открыть</button></div>';

    tickChest();
    if (ui.justWatered) {
      ui.justWatered = false;
      const tc = $('#tree-card'), wrap = $('.tree-wrap', tc);
      tc.classList.add('watered');
      const d = document.createElement('div'); d.className = 'drop-fall'; wrap.appendChild(d); setTimeout(() => d.remove(), 1000);
    }
    if (ui.justSaved) {
      ui.justSaved = false;
      const r = $('#result'); if (r) { r.scrollIntoView({ behavior: 'smooth', block: 'center' }); $$('.big div', r).forEach((d, i) => { d.style.animationDelay = (i * 90) + 'ms'; d.classList.add('pop'); }); }
    }
  }

  function chestLeft() { return state.freeChestAt + L.FREE_CHEST_COOLDOWN - Date.now(); }
  function tickChest() {
    const btn = $('#chest-btn'), hint = $('#chest-hint'); if (!btn) return;
    const left = chestLeft();
    if (left > 0) {
      const h = Math.floor(left / 3600000), m = Math.ceil((left % 3600000) / 60000);
      btn.disabled = true; btn.textContent = 'Откроется через ' + (h ? h + ' ч ' : '') + (m === 60 ? '59' : m) + ' мин';
      hint.textContent = 'Раз в сутки: 10–50 кристаллов, 1–2 капли или пусто.';
    } else {
      btn.disabled = false; btn.textContent = 'Открыть бесплатный сундук';
      hint.textContent = 'Раз в сутки: 10–50 кристаллов, 1–2 капли или пусто. Сегодня он ещё ждёт тебя!';
    }
  }
  setInterval(() => { if (ui.tab === 'today') tickChest(); }, 20000);

  function rewardText(r) {
    if (r.c) return '<div class="reward-big pos">+' + num(r.c) + ' 💎</div>';
    if (r.d) return '<div class="reward-big posd">+' + r.d + ' 💧</div>';
    return '<div class="reward-big muted">Пусто</div>';
  }

  /* ---------- СТАТИСТИКА ---------- */
  function chart7(days) {
    const W = 320, H = 178, top = 26, bot = 28, pl = 8, pr = 8, inner = H - top - bot;
    const max = Math.max(10, Math.ceil(Math.max.apply(null, days.map((d) => d.hours || 0))));
    const bw = 30, gap = (W - pl - pr - bw * 7) / 6;
    const y = (h) => top + inner * (1 - h / max);
    let s = '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Длительность сна за последние 7 дней">';
    s += '<rect x="' + pl + '" y="' + y(8.5) + '" width="' + (W - pl - pr) + '" height="' + (y(7.5) - y(8.5)) + '" rx="6" fill="#6fdc9a" opacity=".14"/>';
    s += '<line x1="' + pl + '" x2="' + (W - pr) + '" y1="' + y(0) + '" y2="' + y(0) + '" stroke="rgba(160,170,255,.2)"/>';
    days.forEach((d, i) => {
      const x = pl + i * (bw + gap), isToday = i === 6;
      const wdl = WD_S[L.parseDate(d.date).getDay()];
      if (d.hours == null) {
        s += '<rect x="' + x + '" y="' + (y(0) - 5) + '" width="' + bw + '" height="5" rx="2.5" fill="rgba(160,170,255,.16)"/>';
      } else {
        const good = d.hours >= 7.5 && d.hours <= 8.5;
        const h = y(0) - y(d.hours);
        s += '<rect class="bar" x="' + x + '" y="' + y(d.hours) + '" width="' + bw + '" height="' + h + '" rx="9" fill="' + (good ? '#6fdc9a' : '#8d7bff') + '"/>';
        s += '<text class="val" x="' + (x + bw / 2) + '" y="' + (y(d.hours) - 6) + '" text-anchor="middle">' + L.fmtNum(Math.round(d.hours * 10) / 10) + '</text>';
      }
      s += '<text x="' + (x + bw / 2) + '" y="' + (H - 8) + '" text-anchor="middle"' + (isToday ? ' style="fill:#ffd86b;font-weight:700"' : '') + '>' + wdl + '</text>';
    });
    return s + '</svg>';
  }

  function renderStats() {
    const t = today(), s = L.stats(state, t);
    const k = (label, val) => '<div class="kpi"><small>' + label + '</small><b>' + val + '</b></div>';
    $('#screen-stats').innerHTML =
      '<h1 class="screen-title">Статистика</h1><p class="screen-sub">Без оценок — просто чтобы видеть, как тебе спится.</p>'
      + '<div class="card"><div class="kpis">'
      + k('Средний отбой, 7 дней', s.bed7 || '—') + k('Средний отбой, 30 дней', s.bed30 || '—')
      + k('Средний сон, 7 дней', L.fmtHours(s.sleep7)) + k('Средний сон, 30 дней', L.fmtHours(s.sleep30))
      + k('Серия сейчас', s.streak + ' ' + L.plural(s.streak, ['день', 'дня', 'дней'])) + k('Лучшая серия', s.best + ' ' + L.plural(s.best, ['день', 'дня', 'дней']))
      + k('Всего кристаллов', num(s.totalCrystals) + ' 💎') + k('Всего капель', L.fmtNum(s.totalDrops) + ' 💧')
      + '</div></div>'
      + '<div class="card"><h2>Сон за 7 дней</h2><div style="margin-top:8px">' + chart7(s.last7) + '</div><p class="small muted" style="margin-top:6px"><span style="color:var(--leaf)">●</span> зелёный столбец и полоса — норма 7.5–8.5 часов</p></div>'
      + '<div class="card"><div class="row between"><h2>Последние записи</h2><span class="small muted">всего ' + s.count + '</span></div>'
      + (s.recent.length ? '<div>' + s.recent.map((e) =>
        '<div class="entry" role="button" tabindex="0" data-act="edit-entry" data-date="' + e.date + '"><div class="d">' + dShort(e.date) + '<small>' + WD_S[L.parseDate(e.date).getDay()] + '</small></div>'
        + '<div class="mid">лёг ' + e.bed + ' · встал ' + e.wake + '<div class="muted small">' + L.fmtHours(e.hours) + ' · ' + L.WEATHER[e.weather].icon + '</div></div>'
        + '<div class="rw"><span class="' + (e.crystals < 0 ? 'neg' : 'pos') + '">' + sg(e.crystals) + ' 💎</span><br><span class="posd">' + sg(e.drops) + ' 💧</span></div></div>').join('') + '</div>'
        : '<div class="empty"><div class="em">🌙</div><p class="muted" style="margin-top:6px">Пока нет записей. Загляни на вкладку «Сегодня» — первая ночь ждёт.</p></div>')
      + (s.recent.length ? '<p class="small muted" style="margin-top:8px">Нажми на запись, чтобы изменить её.</p>' : '') + '</div>';
  }

  /* ---------- ЦЕЛИ ---------- */
  const EXAMPLES = [['Вкусняшки', 500], ['Новый чехол', 1000], ['Поход в кино', 2000]];
  function renderGoals() {
    const goals = state.goals;
    $('#screen-goals').innerHTML =
      '<h1 class="screen-title">Цели</h1><p class="screen-sub">Придумай награду для себя и накопи на неё кристаллами.</p>'
      + '<div class="card"><h2>Новая цель</h2><div class="stack">'
      + '<div><label class="f" for="g-title">Что хочется?</label><input class="inp" id="g-title" maxlength="60" placeholder="Например, поход в кино" value="' + esc(ui.goalTitle) + '"></div>'
      + '<div><label class="f" for="g-cost">Цена в кристаллах</label><input class="inp" id="g-cost" type="number" inputmode="numeric" min="1" placeholder="2000" value="' + esc(ui.goalCost) + '"></div>'
      + '<button class="btn block" data-act="goal-add">Добавить цель</button>' + (ui.msg ? '<div class="msg">' + esc(ui.msg) + '</div>' : '') + '</div></div>'
      + '<div class="card"><h2>Мои цели</h2>'
      + (goals.length ? goals.map((g) => {
        const pct = Math.min(100, Math.floor(state.crystals / g.cost * 100)), can = state.crystals >= g.cost;
        return '<div class="goal"><div class="row between"><b>' + esc(g.title) + '</b><span class="row"><span class="qr">' + num(g.cost) + ' 💎</span><button class="x" data-act="goal-del" data-id="' + g.id + '" aria-label="Удалить цель">×</button></span></div>'
          + '<div class="bar-bg"><div class="bar-fg' + (can ? ' full' : '') + '" style="width:' + pct + '%"></div></div>'
          + '<div class="row between"><span class="small muted">' + num(Math.min(state.crystals, g.cost)) + ' из ' + num(g.cost) + ' (' + pct + '%)</span>'
          + (can ? '<button class="btn leaf sm" data-act="goal-claim" data-id="' + g.id + '">🎉 Забрать награду</button>' : '<span class="small muted">ещё ' + num(g.cost - state.crystals) + ' 💎</span>') + '</div></div>';
      }).join('')
        : '<div class="empty"><div class="em">🎯</div><p class="muted" style="margin-top:6px">Пока целей нет. Вот идеи — нажми, чтобы подставить:</p><div class="suggest">'
          + EXAMPLES.map((x) => '<button class="chip" data-act="goal-example" data-t="' + x[0] + '" data-c="' + x[1] + '">' + x[1] + ' — ' + x[0].toLowerCase() + '</button>').join('') + '</div></div>')
      + '</div>'
      + (state.doneGoals.length ? '<div class="card"><h2>Выполненные</h2>' + state.doneGoals.map((g) =>
        '<div class="entry"><div class="d" style="width:auto;font-size:22px">✅</div><div class="mid"><b>' + esc(g.title) + '</b><div class="muted small">' + dLong(g.date) + '</div></div><div class="rw muted">' + num(g.cost) + ' 💎</div></div>').join('') + '</div>' : '');
  }

  /* ---------- МАГАЗИН ---------- */
  function renderShop() {
    const chips = boosterChips();
    $('#screen-shop').innerHTML =
      '<h1 class="screen-title">Магазин</h1><p class="screen-sub">Бустеры за кристаллы, заработанные сном. За деньги здесь ничего не продаётся.</p>'
      + (chips.length ? '<div class="boosters" style="margin-top:12px">' + chips.map((c) => '<span class="chip on">' + c + '</span>').join('') + '</div>' : '')
      + '<div class="card"><div class="shop-grid">' + L.SHOP.map((it) => {
        const active = it.id !== 'lucky' && it.id !== 'recolor' && state.boosters[it.id];
        let dis = state.crystals < it.price || active, btn = active ? 'Активен ✓' : 'Купить';
        if (it.id === 'recolor') {
          if (!L.branchUnlocked(state)) { dis = true; btn = 'С 7-го дня'; }
          else if (!state.branch) { dis = true; btn = 'Сначала ветка'; }
        }
        return '<div class="item"><div class="ico">' + it.icon + '</div><div class="info"><b>' + it.name + '</b><p>' + it.desc + '</p></div>'
          + '<div style="text-align:right"><div class="qr price" style="margin-bottom:6px">' + it.price + ' 💎</div><button class="btn sm" data-act="buy" data-id="' + it.id + '"' + (dis ? ' disabled' : '') + '>' + btn + '</button></div></div>';
      }).join('') + '</div></div>';
  }

  /* ---------- ПРОФИЛЬ ---------- */
  function renderProfile() {
    const lvl = L.petLevel(state), got = Object.keys(state.badges).length;
    $('#screen-profile').innerHTML =
      '<h1 class="screen-title">Профиль</h1>'
      + '<div class="card pet-card">' + A.petSVG(lvl.level, 'happy')
      + '<input class="petname" id="pet-name" maxlength="20" value="' + esc(state.petName) + '" aria-label="Имя питомца">'
      + '<p class="muted small">' + lvl.name + ' · ночей записано: ' + lvl.count + '</p>'
      + (lvl.next ? '<p class="small" style="margin-top:6px;color:var(--moon)">До уровня «' + lvl.nextName + '» осталось ' + (lvl.next - lvl.count) + ' ' + L.plural(lvl.next - lvl.count, ['ночь', 'ночи', 'ночей']) + '</p>' : '<p class="small" style="margin-top:6px;color:var(--moon)">Максимальный уровень — ты звёздный мастер сна ✨</p>')
      + '</div>'
      + '<div class="card"><div class="row between"><h2>Достижения</h2><span class="small muted">' + got + ' из ' + L.BADGES.length + '</span></div><p class="small muted" style="margin-top:4px">Каждый бейдж даёт +' + L.BADGE_REWARD + ' 💎</p><div class="badges" style="margin-top:12px">'
      + L.BADGES.map((b) => {
        const d = state.badges[b.id];
        return '<div class="badge ' + (d ? 'on' : 'off') + '"><span class="bi">' + b.icon + '</span><b>' + b.name + '</b><small>' + (d ? 'получен ' + dShort(d) : b.hint) + '</small></div>';
      }).join('') + '</div></div>'
      + '<div class="card"><h2>Мои данные</h2><p class="small muted" style="margin-top:4px">Всё хранится только в этом браузере, без регистрации. Чтобы перенести прогресс на другой телефон или не потерять при очистке браузера, сохрани файл.</p>'
      + '<div class="row wrap" style="margin-top:12px"><button class="btn ghost sm grow" data-act="export">⬇️ Экспорт</button><button class="btn ghost sm grow" data-act="import">⬆️ Импорт</button></div>'
      + '<input type="file" id="import-file" accept="application/json,.json" class="hide">'
      + '<p class="small muted" style="margin-top:12px">Совет: в меню браузера выбери «Добавить на главный экран» — Sleepy будет открываться как приложение.</p></div>';
  }

  /* ---------- ПРАВИЛА ---------- */
  function renderRules() {
    const gridRows = L.GRID.map((g) => '<tr><td>' + g.label + '</td><td class="' + (g.crystals < 0 ? 'neg' : 'pos') + '">' + sg(g.crystals) + '</td><td class="posd">' + g.drops + '</td></tr>').join('');
    const wRows = Object.keys(L.WEATHER).map((k) => { const w = L.WEATHER[k]; return '<tr><td>' + w.icon + ' ' + w.name + '</td><td>×' + w.c + '</td><td>×' + w.d + '</td></tr>'; }).join('');
    const shopRows = L.SHOP.map((i) => '<li>' + i.icon + ' <b>' + i.name + '</b> (' + i.price + ' 💎) — ' + i.desc + '</li>').join('');
    const badgeRows = L.BADGES.map((b) => '<li>' + b.icon + ' <b>' + b.name + '</b> — ' + b.hint + '</li>').join('');
    const brRows = Object.keys(L.BRANCHES).map((k) => '<li>' + L.BRANCHES[k].icon + ' <b>' + L.BRANCHES[k].name + '</b> — ' + L.BRANCHES[k].desc + '</li>').join('');
    $('#screen-rules').innerHTML =
      '<h1 class="screen-title">Правила</h1><p class="screen-sub">Коротко и по-человечески: за что что начисляется.</p>'
      + '<div class="card rules"><h2>Как это работает</h2><p>Каждый день записывай, во сколько лёг и во сколько проснулся. Чем раньше отбой, тем больше кристаллов 💎 и капель 💧. Один день — одна запись: если исправишь время, награды просто пересчитаются, дважды они не начисляются. Записать можно и прошлые дни.</p></div>'
      + '<div class="card rules"><h2>Кристаллы и капли за отбой</h2><table class="t"><tr><th>Время отхода</th><th>💎</th><th>💧</th></tr>' + gridRows + '</table>'
      + '<ul><li>Проснулся до 08:00 — бонус <b>+20 💎</b>.</li><li>Штраф −20 💎 — единственный. Баланс никогда не уходит ниже нуля.</li><li>Отбой после полуночи записывай как есть (00:10).</li></ul></div>'
      + '<div class="card rules"><h2>Серия</h2><p>День идёт в серию, если ты лёг до 00:00. Пропуск дня или поздний отбой начинает серию заново (если нет заморозки).</p><ul><li>7 дней подряд — <b>+200 💎</b></li><li>30 дней подряд — <b>+1000 💎</b></li><li>Каждый бонус выдаётся один раз.</li></ul></div>'
      + '<div class="card rules"><h2>Дерево</h2><p>Стадии: росток → с листом → куст → дерево → цветущее. Каждая стадия стоит 5 капель. Капли не сгорают. Дерево никогда не вянет и не умирает: оно либо растёт, либо спокойно ждёт. После цветения новые поливы добавляют светлячков.</p>'
      + '<p style="margin-top:8px">На 7-й день серии выбираешь ветку (бесплатно, один раз):</p><ul>' + brRows + '</ul><p class="small muted" style="margin-top:8px">Сменить ветку позже можно бустером «Перекраска дерева». Бонусы веток складываются с погодой.</p></div>'
      + '<div class="card rules"><h2>Погода сна</h2><p>Зависит от даты и не меняется в течение дня.</p><table class="t"><tr><th>Погода</th><th>💎</th><th>💧</th></tr>' + wRows + '</table><p class="small muted" style="margin-top:8px">Туман: серия держится только при отходе до 23:30. Штраф погода не меняет.</p></div>'
      + '<div class="card rules"><h2>Квесты и сундуки</h2><ul><li>Три квеста каждый день, награда — кристаллы.</li><li>Выполнил все три — открывается сундук: 100–500 💎 или 2–5 💧.</li><li>Бесплатный сундук раз в сутки: 10–50 💎, 1–2 💧 или пусто.</li></ul></div>'
      + '<div class="card rules"><h2>Бустеры</h2><ul>' + shopRows + '</ul></div>'
      + '<div class="card rules"><h2>Достижения</h2><p class="small muted">За каждое — +' + L.BADGE_REWARD + ' 💎.</p><ul>' + badgeRows + '</ul></div>'
      + '<div class="card rules"><h2>Цели</h2><p>Придумай награду и цену. Когда кристаллов хватает — нажми «Забрать награду»: кристаллы спишутся, а цель попадёт в «Выполненные».</p></div>'
      + '<div class="card"><h2>Сброс</h2><p class="small muted" style="margin:6px 0 12px">Удалит все записи, баланс, дерево, цели и достижения в этом браузере. Если сомневаешься, сначала сделай экспорт в профиле.</p><button class="btn danger block" data-act="reset">Сбросить все данные</button></div>';
  }

  /* ---------- Модалки: ветки ---------- */
  function branchModal(mode) {
    const recolor = mode === 'recolor';
    modal({
      emoji: '🌳', title: recolor ? 'Перекрасить дерево' : 'Выбери ветку развития',
      body: '<p class="muted small" style="margin-top:6px">' + (recolor ? 'Новая ветка заменит текущую. Стоимость: <b>500 💎</b>.' : 'Это бесплатно и один раз. Ветка меняет вид дерева и даёт бонус.') + '</p>'
        + '<div class="branch-grid">' + Object.keys(L.BRANCHES).map((k) => {
          const b = L.BRANCHES[k], dis = recolor && state.branch === k;
          return '<button class="branch-opt" data-branch="' + k + '"' + (dis ? ' disabled' : '') + '><span class="bi">' + b.icon + '</span><b>' + b.name + '</b><small>' + b.desc + '</small></button>';
        }).join('') + '</div>',
      actions: [{ label: 'Позже', cls: 'ghost' }],
      onBranch: (id) => {
        const r = recolor ? L.recolor(state, id) : L.chooseBranch(state, id);
        if (r.error) { toast(r.error); return; }
        closeModal(); save(); renderAll(); toast('Теперь это ' + L.BRANCHES[id].icon + ' ' + L.BRANCHES[id].name);
      }
    });
  }

  /* ---------- Действия ---------- */
  function setDate(d) { ui.date = d; loadForm(d); renderToday(); }

  const ACTIONS = {
    'date-today': () => setDate(today()),
    'date-yest': () => setDate(L.addDays(today(), -1)),
    'save-entry': () => {
      ui.bed = $('#f-bed').value; ui.wake = $('#f-wake').value;
      const r = L.saveEntry(state, ui.date, ui.bed, ui.wake, today());
      if (r.error) { ui.msg = r.error; renderToday(); return; }
      ui.msg = ''; ui.justSaved = true; save();
      toast((r.isEdit ? 'Запись обновлена' : 'Ночь записана') + ' 🌙 ' + sg(r.entry.crystals) + ' 💎 ' + sg(r.entry.drops) + ' 💧');
      handleEvents(r.events); renderAll();
    },
    'water': () => {
      const r = L.water(state, today());
      if (r.error) { toast(r.error); return; }
      ui.justWatered = true; save(); handleEvents(r.events);
      toast(r.stage < 4 || r.extra === 0 ? 'Дерево подросло: ' + L.STAGES[r.stage] + ' 🌱' : 'Дерево сияет — появился новый светлячок ✨');
      renderAll();
    },
    'branch-first': () => branchModal('first'),
    'open-qchest': () => {
      const r = L.openQuestChest(state, today());
      if (r.error) { toast(r.error); return; }
      save(); modal({ emoji: '🎁', title: 'Сундук квестов', body: rewardText(r.reward) + '<p class="muted">Ты справился со всеми заданиями дня!</p>', actions: [{ label: 'Класс!' }] });
      handleEvents(r.events); renderAll();
    },
    'open-fchest': () => {
      const r = L.openFreeChest(state, Date.now());
      if (r.error) { toast('Сундук откроется чуть позже.'); tickChest(); return; }
      save();
      modal({ emoji: r.reward.c || r.reward.d ? '🧰' : '📭', title: 'Бесплатный сундук', body: rewardText(r.reward) + '<p class="muted">' + (r.reward.c || r.reward.d ? 'Приятная находка!' : 'В этот раз пусто, зато завтра снова можно попробовать 🍀') + '</p>', actions: [{ label: 'Спасибо' }] });
      handleEvents(r.events); renderAll();
    },
    'edit-entry': (el) => { setDate(el.dataset.date); showTab('today'); },
    'goal-example': (el) => { ui.goalTitle = el.dataset.t; ui.goalCost = el.dataset.c; renderGoals(); },
    'goal-add': () => {
      ui.goalTitle = $('#g-title').value; ui.goalCost = $('#g-cost').value;
      const r = L.addGoal(state, ui.goalTitle, ui.goalCost);
      if (r.error) { ui.msg = r.error; renderGoals(); return; }
      ui.msg = ''; ui.goalTitle = ''; ui.goalCost = ''; save(); toast('Цель добавлена 🎯'); renderGoals();
    },
    'goal-claim': (el) => {
      const r = L.claimGoal(state, el.dataset.id, today());
      if (r.error) { toast(r.error); return; }
      save();
      modal({ emoji: '🎉', title: 'Награда твоя!', body: '<div class="reward-big">' + esc(r.goal.title) + '</div><p class="muted">Списано ' + num(r.goal.cost) + ' 💎. Ты её заслужил.</p>', actions: [{ label: 'Ура!' }] });
      handleEvents(r.events); renderAll();
    },
    'goal-del': (el) => {
      const g = state.goals.find((x) => x.id === el.dataset.id); if (!g) return;
      modal({ title: 'Удалить цель?', body: '<p class="muted" style="margin-top:8px">«' + esc(g.title) + '» исчезнет из списка. Кристаллы не пострадают.</p>', actions: [{ label: 'Удалить', cls: 'danger', onClick: () => { L.deleteGoal(state, g.id); save(); renderGoals(); } }, { label: 'Оставить', cls: 'ghost' }] });
    },
    'buy': (el) => {
      const id = el.dataset.id;
      if (id === 'recolor') { branchModal('recolor'); return; }
      const r = L.buyBooster(state, id, today());
      if (r.error) { toast(r.error); return; }
      save();
      if (r.reward) modal({ emoji: '🎁', title: 'Сундук удачи', body: rewardText(r.reward), actions: [{ label: 'Отлично!' }] });
      else toast('Бустер активирован ✨');
      renderAll();
    },
    'export': () => {
      const blob = new Blob([L.exportData(state)], { type: 'application/json' });
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'sleepy-backup-' + today() + '.json';
      document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
      toast('Файл сохранён ⬇️');
    },
    'import': () => { const f = $('#import-file'); if (f) f.click(); },
    'reset': () => modal({
      emoji: '🧹', title: 'Сбросить все данные?',
      body: '<p class="muted" style="margin-top:8px">Записи, баланс, дерево, цели и достижения будут удалены без возможности вернуть. Точно сбросить?</p>',
      actions: [{ label: 'Да, сбросить всё', cls: 'danger', onClick: () => {
        state = L.newState(); save(); prev.c = prev.d = null; ui.date = today(); loadForm(ui.date); renderAll(); showTab('today'); toast('Всё чисто. Можно начать заново 🌱');
      } }, { label: 'Нет, оставить', cls: 'ghost' }]
    })
  };

  document.addEventListener('click', (e) => {
    const tab = e.target.closest('[data-tab]');
    if (tab) { showTab(tab.dataset.tab); return; }
    const a = e.target.closest('[data-act]');
    if (a && ACTIONS[a.dataset.act]) ACTIONS[a.dataset.act](a);
  });
  document.addEventListener('keydown', (e) => {
    if ((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('[role="button"][data-act]')) { e.preventDefault(); e.target.click(); }
  });
  document.addEventListener('change', (e) => {
    const id = e.target.id;
    if (id === 'f-date') { if (e.target.value) setDate(e.target.value); else e.target.value = ui.date; }
    else if (id === 'f-bed') ui.bed = e.target.value;
    else if (id === 'f-wake') ui.wake = e.target.value;
    else if (id === 'pet-name') { state.petName = e.target.value.trim().slice(0, 20) || 'Совёнок'; e.target.value = state.petName; save(); }
    else if (id === 'import-file') {
      const f = e.target.files && e.target.files[0]; if (!f) return;
      const rd = new FileReader();
      rd.onload = () => {
        const r = L.importData(String(rd.result));
        e.target.value = '';
        if (r.error) { toast(r.error); return; }
        const n = Object.keys(r.state.entries).length;
        modal({ emoji: '⬆️', title: 'Загрузить данные?', body: '<p class="muted" style="margin-top:8px">В файле записей: ' + n + ', кристаллов: ' + num(r.state.crystals) + '. Текущие данные в этом браузере будут заменены.</p>',
          actions: [{ label: 'Заменить', onClick: () => { state = r.state; save(); prev.c = prev.d = null; ui.date = today(); loadForm(ui.date); renderAll(); toast('Данные загружены ✅'); } }, { label: 'Отмена', cls: 'ghost' }] });
      };
      rd.onerror = () => toast('Не получилось прочитать файл.');
      rd.readAsText(f);
    }
  });
  document.addEventListener('input', (e) => {
    if (e.target.id === 'g-title') ui.goalTitle = e.target.value;
    else if (e.target.id === 'g-cost') ui.goalCost = e.target.value;
  });

  /* Смена суток, пока приложение открыто */
  function onVisible() {
    if (document.visibilityState === 'hidden') return;
    const t = today();
    if (t !== ui.todayRef) {
      if (ui.date === ui.todayRef) { ui.date = t; loadForm(t); }
      ui.todayRef = t;
    }
    const ev = []; L.refresh(state, t, ev); save(); handleEvents(ev); renderAll();
  }
  document.addEventListener('visibilitychange', onVisible);

  /* ---------- Старт ---------- */
  renderTabs();
  const startEvents = []; L.refresh(state, today(), startEvents); save();
  renderTop();
  showTab('today', true);
  handleEvents(startEvents);

  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
    window.addEventListener('load', () => { navigator.serviceWorker.register('sw.js').catch(() => {}); });
  }
})();
