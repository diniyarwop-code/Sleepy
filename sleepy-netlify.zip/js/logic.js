/* Sleepy — игровая логика (чистые функции над объектом состояния, без DOM) */
(function (root) {
  'use strict';

  /* ---------- Время и даты ---------- */
  const pad = (n) => String(n).padStart(2, '0');
  const dateStr = (d) => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  const parseDate = (s) => { const p = s.split('-').map(Number); return new Date(p[0], p[1] - 1, p[2], 12); };
  const addDays = (s, n) => { const d = parseDate(s); d.setDate(d.getDate() + n); return dateStr(d); };
  const daysBetween = (a, b) => Math.round((parseDate(b) - parseDate(a)) / 86400000);
  const isDateStr = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s);
  const round2 = (x) => Math.round(x * 100) / 100;

  function parseTime(t) {
    const m = /^(\d{1,2}):(\d{2})$/.exec(String(t || '').trim());
    if (!m) return null;
    const h = +m[1], mi = +m[2];
    if (h > 23 || mi > 59) return null;
    return h * 60 + mi;
  }
  const fmtTime = (min) => { min = ((min % 1440) + 1440) % 1440; return pad(Math.floor(min / 60)) + ':' + pad(min % 60); };
  /* Время отхода: всё, что раньше 12:00, считается «после полуночи» (00:10 → 24:10) */
  const bedMinutes = (m) => (m < 12 * 60 ? m + 1440 : m);
  function fmtHours(h) {
    if (h == null) return '—';
    const total = Math.round(h * 60), hh = Math.floor(total / 60), mm = total % 60;
    return mm ? hh + ' ч ' + mm + ' мин' : hh + ' ч';
  }
  function plural(n, f) {
    n = Math.abs(Math.round(n)); const a = n % 10, b = n % 100;
    if (a === 1 && b !== 11) return f[0];
    if (a >= 2 && a <= 4 && (b < 12 || b > 14)) return f[1];
    return f[2];
  }
  const fmtNum = (n) => { n = round2(n); return Number.isInteger(n) ? String(n) : n.toFixed(1).replace(/\.0$/, ''); };

  /* ---------- Таблицы ---------- */
  const GRID = [
    { until: 23 * 60,      crystals: 350, drops: 7, label: 'до 23:00' },
    { until: 23 * 60 + 10, crystals: 250, drops: 5, label: '23:00–23:09' },
    { until: 23 * 60 + 20, crystals: 150, drops: 3, label: '23:10–23:19' },
    { until: 23 * 60 + 25, crystals: 120, drops: 2, label: '23:20–23:24' },
    { until: 23 * 60 + 30, crystals: 100, drops: 2, label: '23:25–23:29' },
    { until: 23 * 60 + 45, crystals: 50,  drops: 1, label: '23:30–23:44' },
    { until: 24 * 60,      crystals: 25,  drops: 1, label: '23:45–23:59' },
    { until: 24 * 60 + 15, crystals: 10,  drops: 0, label: '00:00–00:14' },
    { until: 24 * 60 + 25, crystals: 5,   drops: 0, label: '00:15–00:24' },
    { until: Infinity,     crystals: -20, drops: 0, label: 'после 00:25' }
  ];
  const tierFor = (bedMin) => GRID.find((t) => bedMin < t.until);

  const WEATHER = {
    clear:   { name: 'Ясно',   icon: '🌙', c: 1,   d: 1,   desc: 'Спокойная ночь без модификаторов.' },
    rain:    { name: 'Дождь',  icon: '🌧️', c: 0.8, d: 1.5, desc: 'Капли ×1.5, кристаллы ×0.8. Хороший день для полива.' },
    storm:   { name: 'Гроза',  icon: '⛈️', c: 1.5, d: 0.5, desc: 'Кристаллы ×1.5, капли ×0.5.' },
    fog:     { name: 'Туман',  icon: '🌫️', c: 1.2, d: 1.2, desc: 'Все награды ×1.2, но серия держится только при отходе до 23:30.' },
    rainbow: { name: 'Радуга', icon: '🌈', c: 2,   d: 2,   desc: 'Редкий день: все награды ×2!' }
  };

  function hash(str) {
    let h = 2166136261 >>> 0;
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    h ^= h >>> 13; h = Math.imul(h, 0x5bd1e995) >>> 0; h ^= h >>> 15;
    return h >>> 0;
  }
  const rnd01 = (str) => hash(str) / 4294967296;

  /* Погода зависит только от даты: у всех одинакова и не меняется в течение дня */
  function weatherFor(date) {
    const r = rnd01('sleepy-weather:' + date);
    if (r < 0.04) return 'rainbow';
    if (r < 0.18) return 'storm';
    if (r < 0.34) return 'fog';
    if (r < 0.58) return 'rain';
    return 'clear';
  }

  const STAGES = ['Росток', 'С листом', 'Куст', 'Дерево', 'Цветущее'];
  const BRANCHES = {
    oak:    { name: 'Дуб',    icon: '🌳', desc: 'Сбалансированный: без бонусов, зато надёжный.' },
    sakura: { name: 'Сакура', icon: '🌸', desc: '+10% капель за каждую ночь.' },
    cactus: { name: 'Кактус', icon: '🌵', desc: '+10% кристаллов за отход после 23:30.' },
    bonsai: { name: 'Бонсай', icon: '🪴', desc: '+1 капля за каждую записанную ночь.' }
  };

  const SHOP = [
    { id: 'freeze',  name: 'Заморозка серии',  price: 300, icon: '❄️', desc: 'Один пропущенный день не сбросит серию.' },
    { id: 'double',  name: 'Двойные капли',    price: 200, icon: '💧', desc: 'Следующая записанная ночь даст капли ×2.' },
    { id: 'shield',  name: 'Щит от штрафа',    price: 150, icon: '🛡️', desc: 'Следующий штраф −20 не сработает.' },
    { id: 'alarm',   name: 'Ранний будильник', price: 250, icon: '⏰', desc: '+100 кристаллов, если на следующую ночь встанешь до 07:00.' },
    { id: 'recolor', name: 'Перекраска дерева', price: 500, icon: '🎨', desc: 'Смена ветки развития: дуб, сакура, кактус или бонсай.' },
    { id: 'lucky',   name: 'Сундук удачи',     price: 400, icon: '🎁', desc: 'Случайно 100–1000 кристаллов или 3–10 капель.' }
  ];

  const BADGES = [
    { id: 'first',     icon: '🌱', name: 'Первая ночь',       hint: 'Запиши свою первую ночь.' },
    { id: 'week',      icon: '🔥', name: 'Неделя силы',       hint: 'Серия 7 дней подряд.' },
    { id: 'month',     icon: '🏆', name: 'Месяц дисциплины',  hint: 'Серия 30 дней подряд.' },
    { id: 'early',     icon: '🐦', name: 'Ранняя птаха',      hint: '10 дней подряд с отходом до 23:00.' },
    { id: 'gardener',  icon: '🌿', name: 'Садовник',          hint: 'Полей дерево 20 раз.' },
    { id: 'collector', icon: '🎯', name: 'Коллекционер',      hint: 'Выполни 10 целей.' },
    { id: 'guard',     icon: '🦉', name: 'Ночной страж',      hint: 'Сделай 100 записей.' },
    { id: 'perfect',   icon: '✨', name: 'Идеальный сон',     hint: '7 дней подряд по 7.5–8.5 часов сна.' }
  ];
  const BADGE_REWARD = 50;

  const QUEST_POOL = {
    bed: [
      { id: 'bed2300', text: 'Ляг до 23:00', reward: 150, test: (s, t, e) => !!e && e.bedMin < 1380 },
      { id: 'bed2315', text: 'Ляг до 23:15', reward: 120, test: (s, t, e) => !!e && e.bedMin < 1395 },
      { id: 'bed2330', text: 'Ляг до 23:30', reward: 80,  test: (s, t, e) => !!e && e.bedMin < 1410 }
    ],
    wake: [
      { id: 'wake0730', text: 'Проснись до 07:30', reward: 100, test: (s, t, e) => !!e && e.wakeMin < 450 },
      { id: 'wake0800', text: 'Проснись до 08:00', reward: 60,  test: (s, t, e) => !!e && e.wakeMin < 480 },
      { id: 'sleep79',  text: 'Поспи от 7 до 9 часов', reward: 100, test: (s, t, e) => !!e && e.hours >= 7 && e.hours <= 9 }
    ],
    act: [
      { id: 'water5',    text: 'Потрать 5 капель на дерево', reward: 50, test: (s, t) => (s.waterLog[t] || 0) >= 1 },
      { id: 'freechest', text: 'Открой бесплатный сундук',   reward: 40, test: (s, t) => !!s.chestLog[t] }
    ]
  };
  const QUEST_BY_ID = {};
  Object.keys(QUEST_POOL).forEach((k) => QUEST_POOL[k].forEach((q) => { QUEST_BY_ID[q.id] = q; }));

  const MILESTONES = [{ days: 7, reward: 200 }, { days: 30, reward: 1000 }];
  const WATER_COST = 5;
  const FREE_CHEST_COOLDOWN = 24 * 3600 * 1000;

  /* ---------- Состояние ---------- */
  function newState() {
    return {
      v: 1,
      crystals: 0, drops: 0,
      totals: { crystals: 0, drops: 0 },
      entries: {},
      streakBest: 0, milestones: {},
      treeWaters: 0, branch: null,
      boosters: { freeze: false, double: false, shield: false, alarm: false },
      freezeCovered: {}, settledThrough: null,
      goals: [], doneGoals: [],
      badges: {},
      quests: {}, waterLog: {}, chestLog: {},
      freeChestAt: 0,
      petName: 'Совёнок'
    };
  }

  function normalizeState(raw) {
    const base = newState();
    if (!raw || typeof raw !== 'object') return base;
    const s = Object.assign(base, raw);
    s.totals = Object.assign({ crystals: 0, drops: 0 }, raw.totals || {});
    s.boosters = Object.assign({ freeze: false, double: false, shield: false, alarm: false }, raw.boosters || {});
    ['entries', 'milestones', 'freezeCovered', 'badges', 'quests', 'waterLog', 'chestLog'].forEach((k) => {
      if (!s[k] || typeof s[k] !== 'object' || Array.isArray(s[k])) s[k] = {};
    });
    ['goals', 'doneGoals'].forEach((k) => { if (!Array.isArray(s[k])) s[k] = []; });
    ['crystals', 'drops', 'streakBest', 'treeWaters', 'freeChestAt'].forEach((k) => { if (!isFinite(s[k])) s[k] = 0; });
    if (!BRANCHES[s.branch]) s.branch = null;
    if (typeof s.petName !== 'string' || !s.petName.trim()) s.petName = 'Совёнок';
    return s;
  }

  function grant(s, c, d) {
    c = c || 0; d = d || 0;
    s.crystals = Math.max(0, Math.round(s.crystals + c));
    s.drops = Math.max(0, round2(s.drops + d));
    if (c > 0) s.totals.crystals += c;
    if (d > 0) s.totals.drops = round2(s.totals.drops + d);
  }

  /* ---------- Подсчёт ночи ---------- */
  function calcNight(bedMin, wakeMin, ctx) {
    const w = WEATHER[ctx.weather] || WEATHER.clear;
    const tier = tierFor(bedMin);
    const lines = [];
    const bedTxt = fmtTime(bedMin);
    let blocked = false;

    if (tier.crystals > 0) {
      lines.push({ text: 'Отбой в ' + bedTxt + ' (' + tier.label + ')', c: tier.crystals, d: tier.drops });
    } else {
      lines.push({ text: 'Отбой в ' + bedTxt + ' (' + tier.label + ')', c: 0, d: 0 });
    }

    /* кристаллы */
    let c1 = tier.crystals > 0 ? Math.round(tier.crystals * w.c) : 0;
    const base = tier.crystals > 0 ? tier.crystals : 0;
    /* капли */
    const v0 = tier.drops;
    const v1 = round2(v0 * w.d);
    const sakura = ctx.branch === 'sakura';
    const v2 = round2(v1 * (sakura ? 1.1 : 1));
    const v3 = round2(v2 * (ctx.dbl ? 2 : 1));

    if (ctx.weather !== 'clear' && (c1 - base !== 0 || v1 - v0 !== 0)) {
      lines.push({ text: 'Погода: ' + w.name, c: c1 - base, d: round2(v1 - v0) });
    }
    if (ctx.branch === 'cactus' && tier.crystals > 0 && bedMin >= 23 * 60 + 30) {
      const c2 = Math.round(c1 * 1.1);
      lines.push({ text: 'Бонус кактуса', c: c2 - c1, d: 0 });
      c1 = c2;
    }
    if (sakura && v2 - v1 !== 0) lines.push({ text: 'Бонус сакуры', c: 0, d: round2(v2 - v1) });
    if (ctx.dbl) lines.push({ text: 'Двойные капли', c: 0, d: round2(v3 - v2) });
    if (ctx.branch === 'bonsai') lines.push({ text: 'Бонсай: пассивная капля', c: 0, d: 1 });

    if (wakeMin < 8 * 60) lines.push({ text: 'Подъём до 08:00', c: Math.round(20 * w.c), d: 0 });
    if (ctx.alarm && wakeMin < 7 * 60) lines.push({ text: 'Ранний будильник сработал', c: 100, d: 0 });

    if (tier.crystals < 0) {
      if (ctx.shield) { blocked = true; lines.push({ text: 'Щит защитил от штрафа', c: 0, d: 0 }); }
      else lines.push({ text: 'Поздний отход', c: tier.crystals, d: 0 });
    }

    const crystals = lines.reduce((a, l) => a + l.c, 0);
    const drops = round2(lines.reduce((a, l) => a + l.d, 0));
    return { tier, lines, crystals, drops, blocked, penalty: tier.crystals < 0 && !blocked };
  }

  /* Идёт ли ночь в серию. Туман: только до 23:30 включительно */
  function qualifies(e) {
    if (e.bedMin >= 1440) return false;
    if (e.weather === 'fog' && e.bedMin > 23 * 60 + 30) return false;
    return true;
  }

  function sortedDates(s) { return Object.keys(s.entries).sort(); }

  function computeStreak(s, today) {
    const dates = sortedDates(s);
    if (!dates.length) return 0;
    let streak = 0;
    let d = dates[0];
    let guard = 0;
    while (d <= today && guard++ < 20000) {
      const e = s.entries[d];
      if (e) streak = qualifies(e) ? streak + 1 : 0;
      else if (d === today) { /* день ещё идёт */ }
      else if (s.freezeCovered[d]) { /* прикрыто заморозкой */ }
      else streak = 0;
      d = addDays(d, 1);
    }
    return streak;
  }

  /* Пропущенные дни: заморозка (если есть) закрывает один день */
  function settle(s, today, events) {
    const dates = sortedDates(s);
    if (!dates.length) return;
    const yesterday = addDays(today, -1);
    let d = s.settledThrough ? addDays(s.settledThrough, 1) : addDays(dates[0], 1);
    if (d <= dates[0]) d = addDays(dates[0], 1);
    let guard = 0;
    while (d <= yesterday && guard++ < 20000) {
      if (!s.entries[d] && !s.freezeCovered[d] && s.boosters.freeze) {
        s.boosters.freeze = false;
        s.freezeCovered[d] = true;
        if (events) events.push({ text: 'Заморозка сохранила твою серию ❄️' });
      }
      d = addDays(d, 1);
    }
    if (!s.settledThrough || s.settledThrough < yesterday) s.settledThrough = yesterday;
  }

  function maxRun(s, pred) {
    const dates = sortedDates(s);
    let best = 0, run = 0, prev = null;
    dates.forEach((d) => {
      const ok = pred(s.entries[d]);
      if (ok && prev && daysBetween(prev, d) === 1 && run > 0) run++;
      else run = ok ? 1 : 0;
      prev = d;
      if (run > best) best = run;
    });
    return best;
  }

  function badgeEarnedNow(s, id) {
    const n = Object.keys(s.entries).length;
    switch (id) {
      case 'first': return n >= 1;
      case 'week': return s.streakBest >= 7;
      case 'month': return s.streakBest >= 30;
      case 'early': return maxRun(s, (e) => e.bedMin < 1380) >= 10;
      case 'gardener': return s.treeWaters >= 20;
      case 'collector': return s.doneGoals.length >= 10;
      case 'guard': return n >= 100;
      case 'perfect': return maxRun(s, (e) => e.hours >= 7.5 && e.hours <= 8.5) >= 7;
    }
    return false;
  }

  function checkBadges(s, today, events) {
    BADGES.forEach((b) => {
      if (!s.badges[b.id] && badgeEarnedNow(s, b.id)) {
        s.badges[b.id] = today;
        grant(s, BADGE_REWARD, 0);
        events.push({ text: 'Новый бейдж: ' + b.icon + ' ' + b.name, c: BADGE_REWARD, badge: b.id });
      }
    });
  }

  /* ---------- Квесты ---------- */
  function questsFor(s, today) {
    let q = s.quests[today];
    if (!q) {
      const pick = (arr, salt) => arr[Math.floor(rnd01('sleepy-quest:' + salt + ':' + today) * arr.length)];
      const act = s.drops >= WATER_COST ? pick(QUEST_POOL.act, 'act') : QUEST_BY_ID.freechest;
      q = { ids: [pick(QUEST_POOL.bed, 'bed').id, pick(QUEST_POOL.wake, 'wake').id, act.id], done: {}, chest: 'none' };
      s.quests[today] = q;
      Object.keys(s.quests).sort().slice(0, -14).forEach((k) => { delete s.quests[k]; });
      Object.keys(s.waterLog).sort().slice(0, -30).forEach((k) => { delete s.waterLog[k]; });
      Object.keys(s.chestLog).sort().slice(0, -30).forEach((k) => { delete s.chestLog[k]; });
    }
    return q.ids.map((id) => Object.assign({}, QUEST_BY_ID[id], { done: !!q.done[id] }));
  }

  function checkQuests(s, today, events) {
    questsFor(s, today);
    const q = s.quests[today];
    const e = s.entries[today];
    q.ids.forEach((id) => {
      const def = QUEST_BY_ID[id];
      if (!q.done[id] && def.test(s, today, e)) {
        q.done[id] = true;
        grant(s, def.reward, 0);
        events.push({ text: 'Квест выполнен: ' + def.text, c: def.reward });
      }
    });
    if (q.chest === 'none' && q.ids.every((id) => q.done[id])) {
      q.chest = 'ready';
      events.push({ text: 'Все квесты выполнены — сундук ждёт тебя! 🎁', chest: true });
    }
  }

  /* ---------- Главный пересчёт ---------- */
  function refresh(s, today, events) {
    settle(s, today, events);
    const streak = computeStreak(s, today);
    if (streak > s.streakBest) s.streakBest = streak;
    MILESTONES.forEach((m) => {
      if (streak >= m.days && !s.milestones[m.days]) {
        s.milestones[m.days] = today;
        grant(s, m.reward, 0);
        events.push({ text: 'Серия ' + m.days + ' ' + plural(m.days, ['день', 'дня', 'дней']) + '! Бонус', c: m.reward });
      }
    });
    if (s.streakBest >= 7 && !s.branch) {
      events.push({ text: 'Дерево готово выбрать свою ветку 🌳', branchUnlock: true });
    }
    checkBadges(s, today, events);
    checkQuests(s, today, events);
    return streak;
  }

  /* ---------- Запись ночи ---------- */
  function saveEntry(s, date, bedStr, wakeStr, today) {
    if (!isDateStr(date)) return { error: 'Выбери дату.' };
    if (date > today) return { error: 'Эта дата ещё не наступила — запиши ночь, когда она пройдёт.' };
    const bm = parseTime(bedStr), wm = parseTime(wakeStr);
    if (bm == null) return { error: 'Укажи, во сколько лёг.' };
    if (wm == null) return { error: 'Укажи, во сколько проснулся.' };
    const bedMin = bedMinutes(bm);
    const dur = (wm - (bedMin % 1440) + 1440) % 1440;
    if (dur < 60 || dur > 18 * 60) return { error: 'Похоже, время перепутано: сон получился ' + (dur < 60 ? 'короче часа' : 'длиннее 18 часов') + '. Проверь, пожалуйста.' };

    const old = s.entries[date];
    const events = [];
    const weather = weatherFor(date);
    const branch = old ? old.branch : s.branch;
    const dbl = old ? !!old.usedDouble : s.boosters.double;
    const alarm = old ? !!old.usedAlarm : s.boosters.alarm;
    const shieldAvail = s.boosters.shield || !!(old && old.shielded);

    const res = calcNight(bedMin, wm, { weather, branch, dbl, alarm, shield: shieldAvail });

    const entry = {
      date, bed: fmtTime(bm), wake: fmtTime(wm), bedMin, wakeMin: wm, hours: dur / 60,
      weather, branch: branch || null,
      crystals: res.crystals, drops: res.drops,
      tier: res.tier.crystals, lines: res.lines,
      usedDouble: dbl, usedAlarm: alarm, shielded: res.blocked,
      createdAt: old ? old.createdAt : Date.now(), updatedAt: Date.now()
    };

    /* расходуем/возвращаем бустеры */
    if (!old) {
      if (dbl) s.boosters.double = false;
      if (alarm) s.boosters.alarm = false;
    }
    if (res.blocked) s.boosters.shield = false;
    else if (old && old.shielded) s.boosters.shield = true;

    const dC = res.crystals - (old ? old.crystals : 0);
    const dD = round2(res.drops - (old ? old.drops : 0));
    s.crystals = Math.max(0, Math.round(s.crystals + dC));
    s.drops = Math.max(0, round2(s.drops + dD));
    s.totals.crystals = Math.max(0, s.totals.crystals + Math.max(0, res.crystals) - (old ? Math.max(0, old.crystals) : 0));
    s.totals.drops = Math.max(0, round2(s.totals.drops + res.drops - (old ? old.drops : 0)));
    s.entries[date] = entry;

    const streak = refresh(s, today, events);
    return { entry, isEdit: !!old, streak, events, delta: { c: dC, d: dD } };
  }

  /* ---------- Дерево ---------- */
  const stageOf = (s) => Math.min(4, s.treeWaters);
  const extraOf = (s) => Math.max(0, s.treeWaters - 4);

  function water(s, today) {
    if (s.drops < WATER_COST - 1e-9) return { error: 'Нужно хотя бы 5 капель. Они копятся с каждой ночью.' };
    s.drops = Math.max(0, round2(s.drops - WATER_COST));
    s.treeWaters += 1;
    s.waterLog[today] = (s.waterLog[today] || 0) + 1;
    const events = [];
    refresh(s, today, events);
    return { stage: stageOf(s), extra: extraOf(s), events };
  }

  const branchUnlocked = (s) => s.streakBest >= 7;

  function chooseBranch(s, id) {
    if (!BRANCHES[id]) return { error: 'Такой ветки нет.' };
    if (!branchUnlocked(s)) return { error: 'Ветка откроется, когда серия дойдёт до 7 дней.' };
    if (s.branch) return { error: 'Ветка уже выбрана. Сменить её можно за «Перекраску дерева».' };
    s.branch = id;
    return { ok: true };
  }

  function recolor(s, id) {
    const price = SHOP.find((x) => x.id === 'recolor').price;
    if (!BRANCHES[id]) return { error: 'Такой ветки нет.' };
    if (!branchUnlocked(s)) return { error: 'Ветка откроется, когда серия дойдёт до 7 дней.' };
    if (!s.branch) return { error: 'Первую ветку можно выбрать бесплатно.' };
    if (id === s.branch) return { error: 'Эта ветка уже выбрана.' };
    if (s.crystals < price) return { error: 'Не хватает кристаллов: нужно ' + price + '.' };
    s.crystals -= price;
    s.branch = id;
    return { ok: true };
  }

  /* ---------- Сундуки ---------- */
  const randInt = (rng, a, b) => a + Math.floor(rng() * (b - a + 1));

  function openFreeChest(s, nowMs, rng) {
    rng = rng || Math.random;
    const left = s.freeChestAt + FREE_CHEST_COOLDOWN - nowMs;
    if (left > 0) return { error: 'cooldown', left };
    const today = dateStr(new Date(nowMs));
    const r = rng();
    let reward;
    if (r < 0.2) reward = { c: 0, d: 0 };
    else if (r < 0.7) reward = { c: randInt(rng, 10, 50), d: 0 };
    else reward = { c: 0, d: randInt(rng, 1, 2) };
    s.freeChestAt = nowMs;
    s.chestLog[today] = true;
    grant(s, reward.c, reward.d);
    const events = [];
    refresh(s, today, events);
    return { reward, events };
  }

  function openQuestChest(s, today, rng) {
    rng = rng || Math.random;
    questsFor(s, today);
    const q = s.quests[today];
    if (q.chest !== 'ready') return { error: 'Сундук ещё закрыт: выполни все три квеста.' };
    q.chest = 'opened';
    const reward = rng() < 0.5 ? { c: randInt(rng, 100, 500), d: 0 } : { c: 0, d: randInt(rng, 2, 5) };
    grant(s, reward.c, reward.d);
    const events = [];
    refresh(s, today, events);
    return { reward, events };
  }

  /* ---------- Магазин ---------- */
  function buyBooster(s, id, today, rng) {
    rng = rng || Math.random;
    const item = SHOP.find((x) => x.id === id);
    if (!item || id === 'recolor') return { error: 'Такого товара нет.' };
    if (s.crystals < item.price) return { error: 'Не хватает кристаллов: нужно ' + item.price + '.' };
    if (id !== 'lucky' && s.boosters[id]) return { error: 'Этот бустер уже активен.' };
    s.crystals -= item.price;
    if (id === 'lucky') {
      const reward = rng() < 0.5 ? { c: randInt(rng, 100, 1000), d: 0 } : { c: 0, d: randInt(rng, 3, 10) };
      grant(s, reward.c, reward.d);
      return { reward, events: [] };
    }
    s.boosters[id] = true;
    return { ok: true, events: [] };
  }

  /* ---------- Цели ---------- */
  function addGoal(s, title, cost) {
    title = String(title || '').trim().slice(0, 60);
    cost = Math.round(Number(cost));
    if (!title) return { error: 'Придумай название награды.' };
    if (!(cost >= 1) || cost > 1000000) return { error: 'Укажи цену в кристаллах (целое число от 1).' };
    const goal = { id: 'g' + Date.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36), title, cost };
    s.goals.push(goal);
    return { goal };
  }

  function claimGoal(s, id, today) {
    const i = s.goals.findIndex((g) => g.id === id);
    if (i < 0) return { error: 'Цель не найдена.' };
    const g = s.goals[i];
    if (s.crystals < g.cost) return { error: 'Пока не хватает кристаллов.' };
    s.crystals -= g.cost;
    s.goals.splice(i, 1);
    s.doneGoals.unshift({ title: g.title, cost: g.cost, date: today });
    const events = [];
    refresh(s, today, events);
    return { goal: g, events };
  }

  function deleteGoal(s, id) {
    const i = s.goals.findIndex((g) => g.id === id);
    if (i >= 0) s.goals.splice(i, 1);
  }

  /* ---------- Статистика ---------- */
  function stats(s, today) {
    const dates = sortedDates(s);
    const within = (n) => dates.filter((d) => d > addDays(today, -n) && d <= today).map((d) => s.entries[d]);
    const avg = (arr, f) => (arr.length ? arr.reduce((a, e) => a + f(e), 0) / arr.length : null);
    const w7 = within(7), w30 = within(30);
    const last7 = [];
    for (let i = 6; i >= 0; i--) {
      const d = addDays(today, -i);
      last7.push({ date: d, hours: s.entries[d] ? s.entries[d].hours : null });
    }
    const bed7 = avg(w7, (e) => e.bedMin), bed30 = avg(w30, (e) => e.bedMin);
    return {
      bed7: bed7 == null ? null : fmtTime(Math.round(bed7)),
      bed30: bed30 == null ? null : fmtTime(Math.round(bed30)),
      sleep7: avg(w7, (e) => e.hours),
      sleep30: avg(w30, (e) => e.hours),
      streak: computeStreak(s, today),
      best: s.streakBest,
      totalCrystals: s.totals.crystals,
      totalDrops: s.totals.drops,
      count: dates.length,
      last7,
      recent: dates.slice(-14).reverse().map((d) => s.entries[d])
    };
  }

  /* ---------- Питомец ---------- */
  const PET_LEVELS = [
    { from: 0,   name: 'Малыш-совёнок' },
    { from: 7,   name: 'Сонный совёнок' },
    { from: 30,  name: 'Лунная сова' },
    { from: 100, name: 'Звёздная сова' }
  ];
  function petLevel(s) {
    const n = Object.keys(s.entries).length;
    let lvl = 0;
    PET_LEVELS.forEach((l, i) => { if (n >= l.from) lvl = i; });
    const next = PET_LEVELS[lvl + 1] || null;
    return { level: lvl, name: PET_LEVELS[lvl].name, count: n, next: next ? next.from : null, nextName: next ? next.name : null };
  }

  /* ---------- Экспорт / импорт ---------- */
  function exportData(s) { return JSON.stringify({ app: 'sleepy', version: 1, exportedAt: new Date().toISOString(), data: s }, null, 1); }
  function importData(text) {
    let obj;
    try { obj = JSON.parse(text); } catch (e) { return { error: 'Не получилось прочитать файл: это не JSON.' }; }
    if (!obj || obj.app !== 'sleepy' || !obj.data || typeof obj.data !== 'object') return { error: 'Это не файл с данными Sleepy.' };
    return { state: normalizeState(obj.data) };
  }

  const api = {
    GRID, WEATHER, STAGES, BRANCHES, SHOP, BADGES, QUEST_POOL, MILESTONES, WATER_COST, BADGE_REWARD, FREE_CHEST_COOLDOWN, PET_LEVELS,
    pad, dateStr, parseDate, addDays, daysBetween, parseTime, fmtTime, fmtHours, fmtNum, plural, bedMinutes, round2,
    tierFor, weatherFor, newState, normalizeState, calcNight, qualifies, computeStreak, settle, refresh,
    saveEntry, water, stageOf, extraOf, branchUnlocked, chooseBranch, recolor,
    openFreeChest, openQuestChest, buyBooster, questsFor, checkQuests, checkBadges, badgeEarnedNow,
    addGoal, claimGoal, deleteGoal, stats, petLevel, exportData, importData, grant
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.SleepyLogic = api;
})(typeof window !== 'undefined' ? window : globalThis);
